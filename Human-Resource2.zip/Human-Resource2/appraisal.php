
<?php include 'includes/header.php' ?>
<?php include 'includes/navbar.php' ?>
<?php include 'includes/sidebar.php' ?>
<div id="layoutSidenav_content">

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Appraisal Management System</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/tailwindcss/2.2.19/tailwind.min.css" rel="stylesheet">
    <script>
        // Function to handle file upload and link generation
        function handleFileUpload(input, id) {
            const file = input.files[0];
            if (file) {
                const fileName = file.name;
                const fileURL = URL.createObjectURL(file);
                const linkContainer = document.getElementById(id);
                linkContainer.innerHTML = `<a href="${fileURL}" target="_blank" class="text-blue-500 hover:underline">${fileName}</a>`;
                // Add a 'file-uploaded' class to change the design
                input.parentElement.classList.add('file-uploaded');
            }
        }

        function toggleButtons() {
            const buttonsDiv = document.getElementById('actionButtons');
            buttonsDiv.classList.toggle('hidden');
        }
    </script>
    <style>
        .file-input {
            display: none;
        }

        .custom-file-upload {
            display: inline-block;
            padding: 15px 40px;
            cursor: pointer;
            border-radius: 10px;
            background: linear-gradient(90deg, #4ade80, #38b700);
            color: white;
            font-weight: bold;
            text-transform: uppercase;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.3);
            transition: all 0.3s ease;
        }

        .custom-file-upload:hover {
            background: linear-gradient(90deg, #38b700, #4ade80);
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.4);
        }

        .custom-file-upload:active {
            transform: translateY(0);
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.3);
        }

        /* Change design when file is uploaded */
        .file-uploaded {
            background: linear-gradient(90deg, #00bfa6, #006b6b);
            color: white;
        }

        .file-uploaded:hover {
            background: linear-gradient(90deg, #006b6b, #00bfa6);
        }
    </style>
</head>

<body class="bg-gray-100">
    <header class="bg-green-500 text-white p-6 text-center relative">
        <h1 class="text-4xl font-bold">Appraisal Management System</h1>
        <nav class="mt-4">
            <!-- Navigation can go here -->
        </nav>

        <!-- Toggle Button to Hide/Unhide (Small Circle) -->
        <button onclick="toggleButtons()" class="absolute top-6 right-6 bg-green-700 text-white rounded-full flex items-center justify-center w-8 h-8 hover:bg-green-900 transition duration-300">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                <path stroke-linecap="round" stroke-linejoin="round" d="M12 4v16m8-8H4" />
            </svg>
        </button>

        <!-- Action Buttons -->
        <div id="actionButtons" class="absolute top-15 right-4 flex flex-col space-y-2 hidden">
            <button class="bg-green-500 text-white py-2 px-4 rounded-lg shadow-md hover:bg-green-600 transition duration-300 text-sm font-semibold">ADD</button>
            <button class="bg-red-500 text-white py-2 px-4 rounded-lg shadow-md hover:bg-red-600 transition duration-300 text-sm font-semibold">DELETE</button>
            <button class="bg-blue-500 text-white py-2 px-4 rounded-lg shadow-md hover:bg-blue-600 transition duration-300 text-sm font-semibold">EDIT</button>
        </div>
    </header>

    <!-- PDF Upload Boxes -->
    <div class="bg-gray-100 p-10 flex-grow">
        <div class="flex flex-wrap justify-center gap-6 relative z-1">
            <!-- Box 1 -->
            <div class="bg-white shadow-lg rounded-lg p-10 flex flex-col items-center w-96 hover:shadow-xl transition duration-300">
                <label class="custom-file-upload mb-4">
                    <input type="file" accept="application/pdf" class="file-input" onchange="handleFileUpload(this, 'fileLink1')">
                    Choose PDF
                </label>
                <h2 class="text-lg font-bold text-center mb-2 text-black">Upload PDF 1</h2>
                <div id="fileLink1"></div> <!-- Display file link here -->
            </div>

            <!-- Box 2 -->
            <div class="bg-white shadow-lg rounded-lg p-10 flex flex-col items-center w-96 hover:shadow-xl transition duration-300">
                <label class="custom-file-upload mb-4">
                    <input type="file" accept="application/pdf" class="file-input" onchange="handleFileUpload(this, 'fileLink2')">
                    Choose PDF
                </label>
                <h2 class="text-lg font-bold text-center mb-2 text-black">Upload PDF 2</h2>
                <div id="fileLink2"></div> <!-- Display file link here -->
            </div>

            <!-- Box 3 -->
            <div class="bg-white shadow-lg rounded-lg p-10 flex flex-col items-center w-96 hover:shadow-xl transition duration-300">
                <label class="custom-file-upload mb-4">
                    <input type="file" accept="application/pdf" class="file-input" onchange="handleFileUpload(this, 'fileLink3')">
                    Choose PDF
                </label>
                <h2 class="text-lg font-bold text-center mb-2 text-black">Upload PDF 3</h2>
                <div id="fileLink3"></div> <!-- Display file link here -->
            </div>

            <!-- Box 4 -->
            <div class="bg-white shadow-lg rounded-lg p-10 flex flex-col items-center w-96 hover:shadow-xl transition duration-300">
                <label class="custom-file-upload mb-4">
                    <input type="file" accept="application/pdf" class="file-input" onchange="handleFileUpload(this, 'fileLink4')">
                    Choose PDF
                </label>
                <h2 class="text-lg font-bold text-center mb-2 text-black">Upload PDF 4</h2>
                <div id="fileLink4"></div> <!-- Display file link here -->
            </div>

            <!-- Box 5 -->
            <div class="bg-white shadow-lg rounded-lg p-10 flex flex-col items-center w-96 hover:shadow-xl transition duration-300">
                <label class="custom-file-upload mb-4">
                    <input type="file" accept="application/pdf" class="file-input" onchange="handleFileUpload(this, 'fileLink5')">
                    Choose PDF
                </label>
                <h2 class="text-lg font-bold text-center mb-2 text-black">Upload PDF 5</h2>
                <div id="fileLink5"></div> <!-- Display file link here -->
            </div>
        </div>
    </div>
</body>

</html>


<?php include 'includes/script.php' ?>
<?php include 'includes/footer.php' ?>
