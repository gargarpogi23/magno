
<?php include 'includes/header.php' ?>
<?php include 'includes/navbar.php' ?>
<?php include 'includes/sidebar.php' ?>
<div id="layoutSidenav_content">

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Futuristic Performance Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #e0f7fa 30%, #80deea 70%);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            color: #333;
        }
        .card {
            background: rgba(255, 255, 255, 0.9);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s, box-shadow 0.3s;
        }
        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 50px rgba(0, 0, 0, 0.15);
        }
        .employee-photo {
            border: 4px solid #00b4d8;
        }
        .chart-container {
            height: 600px; /* Fixed height */
            position: relative;
            margin-bottom: 30px; /* Increased space below the chart */
        }
        h2 {
            text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.1);
        }
        .employee-list li {
            transition: background-color 0.3s, transform 0.2s;
        }
        .employee-list li:hover {
            background-color: #38a169;
            color: white;
            transform: scale(1.05);
        }
        .tooltip {
            display: none;
            position: absolute;
            background: rgba(0, 0, 0, 0.7);
            color: white;
            padding: 5px;
            border-radius: 5px;
            font-size: 12px;
            pointer-events: none;
            z-index: 10;
        }
        .metric-card {
            transition: transform 0.3s;
            padding: 20px; /* Increased padding inside the metric cards */
            margin-right: 10px; /* Add right margin between cards */
        }
        .metric-card:hover {
            transform: scale(1.05);
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.2);
        }
    </style>
</head>
<body class="h-screen">

    <div class="flex h-full">
        <!-- Sidebar for employee list and profile -->
        <div class="w-1/4 bg-white p-4 shadow-md card overflow-y-auto">
            <h1 class="text-green-700 text-2xl font-bold mb-4 text-center">Performance Management System</h1>

            <h2 class="text-green-700 text-lg font-semibold mb-4">Employee Profile</h2>
            <div class="bg-gray-100 p-2 rounded-lg mb-6 flex items-center">
                <img id="profile-pic" class="w-16 h-16 rounded-full border-4 employee-photo" src="https://via.placeholder.com/100" alt="Employee Photo">
                <div class="ml-4">
                    <p id="profile-name" class="text-lg text-grey-800">John Doe</p>
                    <p id="profile-role" class="text-green-700">Software Engineer</p>
                    <p id="profile-email" class="text-gray-500 text-sm">Email: john.doe@example.com</p>
                    <p id="profile-phone" class="text-gray-500 text-sm">Phone: (555) 123-4567</p>
                    <p id="profile-linkedin" class="text-gray-500 text-sm">LinkedIn: <a href="#" class="text-blue-500 hover:underline">linkedin.com/johndoe</a></p>
                </div>
            </div>

            <h2 class="text-green-700 text-lg font-semibold mb-2">Employee List</h2>
            <ul class="list-none p-0 employee-list">
                <li onclick="updateProfile('John Doe')" class="p-2 mb-2 rounded cursor-pointer hover:bg-green-200">John Doe</li>
                <li onclick="updateProfile('Jane Smith')" class="p-2 mb-2 rounded cursor-pointer hover:bg-green-200">Jane Smith</li>
                <li onclick="updateProfile('Michael Brown')" class="p-2 mb-2 rounded cursor-pointer hover:bg-green-200">Michael Brown</li>
                <li onclick="updateProfile('Sarah Johnson')" class="p-2 mb-2 rounded cursor-pointer hover:bg-green-200">Sarah Johnson</li>
            </ul>
        

        <button class="bg-green-300 hover:bg-green-500 text-white-500 font-bold py-2 px-4 rounded-full focus:outline-none focus:ring-4 focus:ring-green-300 transition duration-300 ease-in-out">
            +
               </button>
        </div>


        <!-- Main content area -->
        <div class="w-3/4 ml-6 h-full overflow-y-auto">
            <!-- Performance Metrics Section -->
            <div class="bg-white p-4 shadow-md card mb-6">
                <h2 class="text-green-700 text-lg font-semibold mb-4">Performance Metrics (Monthly)</h2>
                <div class="chart-container">
                    <canvas id="performanceChart" class="h-full"></canvas>
                    <div id="tooltip" class="tooltip"></div>
                </div>
                <div class="flex justify-between mt-4">
                    <!-- Performance Score -->
                    <div class="bg-gradient-to-r from-green-400 to-blue-500 p-4 rounded-lg text-center metric-card w-1/3">
                        <h3 class="text-white text-sm font-semibold">Performance Score</h3>
                        <p id="performance-score" class="text-2xl font-bold text-white">85%</p>
                    </div>
                    <!-- Rank -->
                    <div class="bg-gradient-to-r from-blue-400 to-purple-500 p-4 rounded-lg text-center metric-card w-1/3">
                        <h3 class="text-white text-sm font-semibold">Rank</h3>
                        <p id="performance-rank" class="text-2xl font-bold text-white">3rd</p>
                    </div>
                </div>
            </div>

            <!-- Employee Goals Section -->
            <div class="bg-white p-4 shadow-md card mb-6">
                <h2 class="text-green-700 text-lg font-semibold mb-2">Goals Achieved</h2>
                <ul id="goal-list" class="list-disc pl-5">
                    <li>Implemented new features in project A</li>
                    <li>Increased team efficiency by 15%</li>
                    <li>Reduced code errors by 10%</li>
                </ul>
            </div>

            <!-- Performance Reviews Section -->
            <div class="bg-white p-4 shadow-md card mb-6">
                <h2 class="text-green-700 text-lg font-semibold mb-2">Performance Reviews</h2>
                <div id="review-list" class="reviews">
                    <p>Great coding skills</p>
                    <p>Needs to improve time management</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Include Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <script>
        const performanceData = {
            'John Doe': {
                role: 'Software Engineer',
                imgSrc: 'https://via.placeholder.com/100',
                email: 'john.doe@example.com',
                phone: '(555) 123-4567',
                linkedin: 'linkedin.com/johndoe',
                taskCompletion: [60, 70, 75, 80, 90, 85, 70, 80, 75, 80],
                goalAchievement: [70, 65, 60, 75, 80, 90, 85, 80, 75, 85],
                goals: ['Implemented new features in project A', 'Increased team efficiency by 15%', 'Reduced code errors by 10%'],
                reviews: ['Great coding skills', 'Needs to improve time management'],
                performanceScore: 85,
                rank: 3
            },
            'Jane Smith': {
                role: 'Project Manager',
                imgSrc: 'https://via.placeholder.com/100',
                email: 'jane.smith@example.com',
                phone: '(555) 987-6543',
                linkedin: 'linkedin.com/janesmith',
                taskCompletion: [80, 85, 90, 95, 100, 95, 90, 85, 80, 75],
                goalAchievement: [85, 90, 95, 100, 95, 90, 85, 80, 75, 70],
                goals: ['Delivered project A on time', 'Led team training sessions'],
                reviews: ['Excellent leadership skills', 'Very organized'],
                performanceScore: 90,
                rank: 1
            },
            'Michael Brown': {
                role: 'UX Designer',
                imgSrc: 'https://via.placeholder.com/100',
                email: 'michael.brown@example.com',
                phone: '(555) 456-7890',
                linkedin: 'linkedin.com/michaelbrown',
                taskCompletion: [70, 75, 80, 85, 90, 95, 90, 85, 80, 75],
                goalAchievement: [75, 80, 85, 90, 85, 80, 75, 70, 65, 70],
                goals: ['Redesigned project B interface', 'Conducted user testing'],
                reviews: ['Creative and innovative', 'Needs to improve on meeting deadlines'],
                performanceScore: 80,
                rank: 4
            },
            'Sarah Johnson': {
                role: 'Data Analyst',
                imgSrc: 'https://via.placeholder.com/100',
                email: 'sarah.johnson@example.com',
                phone: '(555) 321-0987',
                linkedin: 'linkedin.com/sarahjohnson',
                taskCompletion: [80, 85, 90, 85, 80, 75, 90, 85, 80, 75],
                goalAchievement: [85, 90, 85, 80, 75, 70, 80, 85, 90, 95],
                goals: ['Delivered insights on project C', 'Improved data accuracy by 15%'],
                reviews: ['Analytical and detail-oriented', 'Needs to communicate findings more effectively'],
                performanceScore: 75,
                rank: 5
            }
        };

        const ctx = document.getElementById('performanceChart').getContext('2d');
        const performanceChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: Array.from({ length: 10 }, (_, i) => `Week ${i + 1}`),
                datasets: [{
                    label: 'Task Completion (%)',
                    borderColor: 'rgba(75, 192, 192, 1)',
                    backgroundColor: 'rgba(75, 192, 192, 0.2)',
                    data: [],
                    fill: true
                }, {
                    label: 'Goal Achievement (%)',
                    borderColor: 'rgba(153, 102, 255, 1)',
                    backgroundColor: 'rgba(153, 102, 255, 0.2)',
                    data: [],
                    fill: true
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 100
                    }
                }
            }
        });

        function updateProfile(employeeName) {
            const employee = performanceData[employeeName];
            if (employee) {
                document.getElementById('profile-name').innerText = employeeName;
                document.getElementById('profile-role').innerText = employee.role;
                document.getElementById('profile-pic').src = employee.imgSrc;
                document.getElementById('profile-email').innerText = `Email: ${employee.email}`;
                document.getElementById('profile-phone').innerText = `Phone: ${employee.phone}`;
                document.getElementById('profile-linkedin').innerText = `LinkedIn: ${employee.linkedin}`;
                
                performanceChart.data.datasets[0].data = employee.taskCompletion;
                performanceChart.data.datasets[1].data = employee.goalAchievement;
                performanceChart.update();

                document.getElementById('performance-score').innerText = `${employee.performanceScore}%`;
                document.getElementById('performance-rank').innerText = `${employee.rank}${getOrdinal(employee.rank)}`;

                const goalList = document.getElementById('goal-list');
                goalList.innerHTML = '';
                employee.goals.forEach(goal => {
                    const li = document.createElement('li');
                    li.innerText = goal;
                    goalList.appendChild(li);
                });

                const reviewList = document.getElementById('review-list');
                reviewList.innerHTML = '';
                employee.reviews.forEach(review => {
                    const p = document.createElement('p');
                    p.innerText = review;
                    reviewList.appendChild(p);
                });
            }
        }

        function getOrdinal(n) {
            const suffixes = ["th", "st", "nd", "rd"];
            const mod100 = n % 100;
            return suffixes[(mod100 - 20) % 10] || suffixes[mod100] || suffixes[0];
        }

        // Initial profile display
        updateProfile('John Doe');
    </script>
</body>
</html>


<?php include 'includes/script.php' ?>
<?php include 'includes/footer.php' ?>
