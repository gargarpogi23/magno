<?php include 'includes/header.php' ?>
<?php include 'includes/navbar.php' ?>
<?php include 'includes/sidebar.php' ?>
<div id="layoutSidenav_content">
    <main>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee Recognition</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="transparent">
<div class="watermark-log">
                            <img src="assets/img/logo.png" alt="Watermark Logo">
                                    </div>
                                    <div class="row">
   

    <div class="bg-green-500 text-white text-center py-6">
        <h1 class="text-3xl font-bold">Employee Recognition</h1>
    </div>

    <div class="container mx-auto mt-10 bg-white shadow-md rounded-lg p-6">
        <!-- Nomination Form Section -->
        <div class="section mb-8">
            <h2 class="text-2xl font-bold text-gray-800 border-b-4 border-green-600 pb-2">Employee Nomination Form</h2>
            <form id="nominationForm" class="mt-4 space-y-4">
                <div>
                    <label for="name" class="block text-gray-700 font-semibold">Nominee's Name:</label>
                    <input type="text" id="name" name="name" class="w-full px-4 py-2 border rounded-md text-black" required>
                </div>

                <div>
                    <label for="email" class="block text-gray-700 font-semibold">Nominee's Email:</label>
                    <input type="email" id="email" name="email" class="w-full px-4 py-2 border rounded-md text-black" required>
                </div>

                <div>
                    <label for="category" class="block text-gray-700 font-semibold">Recognition Category:</label>
                    <select id="category" name="category" class="w-full px-4 py-2 border rounded-md text-black" required>
                        <option value="performance">Performance-Based</option>
                        <option value="service">Service Milestones</option>
                        <option value="behavioral">Behavioral Recognition</option>
                        <option value="peer">Peer-to-Peer Recognition</option>
                        <option value="spot">Spot Awards</option>
                    </select>
                </div>

                <div>
                    <label for="description" class="block text-gray-700 font-semibold">Reason for Nomination:</label>
                    <textarea id="description" name="description" rows="4" class="w-full px-4 py-2 border rounded-md text-black" required></textarea>
                </div>

                <button type="submit" class="w-full bg-green-500 text-white py-2 rounded-md hover:bg-green-700 ">Submit Nomination</button>
            </form>
        </div>

        <!-- Rewards Table Section -->
        <div class="section">
            <h2 class="text-2xl font-bold text-gray-500 border-b-4 border-green-600 pb-2">Recognized Employees</h2>

            <div class="filter my-4">
                <label for="filterCategory" class="block text-gray-700 font-semibold">Filter by Category:</label>
                <select id="filterCategory" onchange="filterRewards()" class="w-full px-4 py-2 border rounded-md text-black">
                    <option value="all">All</option>
                    <option value="performance">Performance-Based</option>
                    <option value="service">Service Milestones</option>
                    <option value="behavioral">Behavioral Recognition</option>
                    <option value="peer">Peer-to-Peer Recognition</option>
                    <option value="spot">Spot Awards</option>
                </select>
            </div>

            <table class="w-full table-auto border-collapse">
                <thead>
                    <tr class="bg-green-500 text-white">
                        <th class="px-4 py-2 border">Name</th>
                        <th class="px-4 py-2 border">Email</th>
                        <th class="px-4 py-2 border">Category</th>
                        <th class="px-4 py-2 border">Reason</th>
                    </tr>
                </thead>
                <tbody id="rewardsTable" class="bg-white">
                    <!-- Dynamic entries will appear here -->
                </tbody>
            </table>
        </div>
    </div>

    <div class="text-center py-4 bg-green-500 text-white">
        <p>&copy; 2024 Employee Recognition Program</p>
    </div>

    <script>
        // Array to store the nominations
        const nominations = [];

        // Function to add nomination to the table
        function addNominationToTable(name, email, category, description) {
            const table = document.getElementById('rewardsTable');
            const newRow = document.createElement('tr');

            newRow.innerHTML = `
                <td class="border px-4 py-2">${name}</td>
                <td class="border px-4 py-2">${email}</td>
                <td class="border px-4 py-2">${category}</td>
                <td class="border px-4 py-2">${description}</td>
            `;
            table.appendChild(newRow);
        }

        // Handle form submission
        document.getElementById('nominationForm').addEventListener('submit', function (event) {
            event.preventDefault();

            const name = document.getElementById('name').value;
            const email = document.getElementById('email').value;
            const category = document.getElementById('category').value;
            const description = document.getElementById('description').value;

            // Add the nomination to the array
            nominations.push({ name, email, category, description });

            // Add the nomination to the table
            addNominationToTable(name, email, category, description);

            // Clear form
            document.getElementById('nominationForm').reset();
        });

        // Filter nominations based on category
        function filterRewards() {
            const filterValue = document.getElementById('filterCategory').value;
            const table = document.getElementById('rewardsTable');

            // Clear existing table rows
            table.innerHTML = '';

            // Add filtered nominations to the table 
            nominations.forEach(nomination => {
                if (filterValue === 'all' || nomination.category === filterValue) {
                    addNominationToTable(nomination.name, nomination.email, nomination.category, nomination.description)
                }
            });
        }
    </script>

</body>

</html>

    </main>

<?php include 'includes/script.php' ?>
<?php include 'includes/footer.php' ?>
