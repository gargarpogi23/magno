
<?php include 'includes/header.php' ?>
<?php include 'includes/navbar.php' ?>
<?php include 'includes/sidebar.php' ?>
<div id="layoutSidenav_content">

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <title>Enhanced 360 Feedback</title>
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #f0f4f8;
        }
        .pulse-button {
            transition: transform 0.3s ease-in-out, background 0.3s ease-in-out;
        }
        .pulse-button:hover {
            transform: scale(1.05);
            background: linear-gradient(to right, #22c55e, #3b82f6);
        }
        .card-hover:hover {
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.15);
            transform: translateY(-5px);
        }
        .animated-placeholder::placeholder {
            transition: color 0.2s ease-in-out;
        }
        .animated-placeholder:focus::placeholder {
            color: transparent;
        }
    </style>
</head>
<body class="bg-gray-50">

    <!-- Header -->
    <header class="bg-gradient-to-r from-green-400 to-blue-500 text-white py-8 shadow-md">
        <div class="container mx-auto">
            <h1 class="text-4xl font-bold text-center">360-Degree Feedback</h1>
        </div>
    </header>

    <!-- Main Content -->
    <main class="container mx-auto p-8">
        <div class="bg-white p-8 rounded-lg shadow-lg card-hover transition-all transform hover:shadow-xl">

            <!-- Employee Selection -->
            <div class="mb-8">
                <label for="employee" class="block text-xl font-medium text-gray-700 mb-2">Select Employee:</label>
                <select id="employee" class="w-full px-4 py-3 border border-gray-300 rounded-lg text-gray-900 focus:ring focus:ring-blue-300 transition-all">
                    <option value="">--Select Employee--</option>
                    <option value="1">Jaycob Magno</option>
                    <option value="2">Edrianne Luangco (Peer)</option>
                    <option value="3">Vegeta (Subordinate)</option>
                </select>
            </div>

            <!-- Respondent Role -->
            <div class="mb-8">
                <label for="relationship" class="block text-xl font-medium text-gray-700 mb-2">Your Role:</label>
                <select id="relationship" class="w-full px-4 py-3 border border-gray-300 rounded-lg text-gray-900 focus:ring focus:ring-blue-300 transition-all">
                    <option value="manager">Manager</option>
                    <option value="peer">Peer</option>
                    <option value="direct-report">Direct Report</option>
                    <option value="self">Self</option>
                </select>
            </div>

            <!-- Competency Assessment -->
            <div class="mb-8">
                <h2 class="text-2xl font-semibold text-gray-800 mb-4">Assess Core Competencies for <span id="employeeName" class="font-bold">Selected Employee</span></h2>
                <table class="w-full mt-4 border-collapse text-center text-black">
                    <thead class="bg-gray-100">
                        <tr>
                            <th class="py-3 px-6">Competency</th>
                            <th class="py-3 px-6">1</th>
                            <th class="py-3 px-6">2</th>
                            <th class="py-3 px-6">3</th>
                            <th class="py-3 px-6">4</th>
                            <th class="py-3 px-6">5</th>
                        </tr>
                    </thead>
                    <tbody>
                        <!-- Row 1 -->
                        <tr class="hover:bg-gray-50 transition">
                            <td class="py-4 px-6">Demonstrates leadership in achieving goals</td>
                            <td class="py-4 px-6"><input type="radio" name="leadership1" value="1" class="form-radio h-5 w-5 text-green-600"></td>
                            <td class="py-4 px-6"><input type="radio" name="leadership1" value="2" class="form-radio h-5 w-5 text-green-600"></td>
                            <td class="py-4 px-6"><input type="radio" name="leadership1" value="3" class="form-radio h-5 w-5 text-green-600"></td>
                            <td class="py-4 px-6"><input type="radio" name="leadership1" value="4" class="form-radio h-5 w-5 text-green-600"></td>
                            <td class="py-4 px-6"><input type="radio" name="leadership1" value="5" class="form-radio h-5 w-5 text-green-600"></td>
                        </tr>
                        <!-- Row 2 -->
                        <tr class="hover:bg-gray-50 transition">
                            <td class="py-4 px-6">Inspires and motivates others</td>
                            <td class="py-4 px-6"><input type="radio" name="leadership2" value="1" class="form-radio h-5 w-5 text-green-600"></td>
                            <td class="py-4 px-6"><input type="radio" name="leadership2" value="2" class="form-radio h-5 w-5 text-green-600"></td>
                            <td class="py-4 px-6"><input type="radio" name="leadership2" value="3" class="form-radio h-5 w-5 text-green-600"></td>
                            <td class="py-4 px-6"><input type="radio" name="leadership2" value="4" class="form-radio h-5 w-5 text-green-600"></td>
                            <td class="py-4 px-6"><input type="radio" name="leadership2" value="5" class="form-radio h-5 w-5 text-green-600"></td>
                        </tr>
                        <!-- Row 3 -->
                        <tr class="hover:bg-gray-50 transition">
                            <td class="py-4 px-6">Communicates clearly and effectively</td>
                            <td class="py-4 px-6"><input type="radio" name="communication1" value="1" class="form-radio h-5 w-5 text-green-600"></td>
                            <td class="py-4 px-6"><input type="radio" name="communication1" value="2" class="form-radio h-5 w-5 text-green-600"></td>
                            <td class="py-4 px-6"><input type="radio" name="communication1" value="3" class="form-radio h-5 w-5 text-green-600"></td>
                            <td class="py-4 px-6"><input type="radio" name="communication1" value="4" class="form-radio h-5 w-5 text-green-600"></td>
                            <td class="py-4 px-6"><input type="radio" name="communication1" value="5" class="form-radio h-5 w-5 text-green-600"></td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <!-- Open-Ended Questions -->
            <div class="mb-8">
                <h2 class="text-2xl font-semibold text-gray-800 mb-4">Provide Open-Ended Feedback</h2>
                <div class="space-y-6">
                    <div>
                        <label for="strengths" class="block text-lg font-medium text-gray-700 mb-2">Strengths:</label>
                        <textarea id="strengths" rows="4" class="w-full px-4 py-3 border border-gray-300 rounded-lg animated-placeholder focus:ring focus:ring-green-300 text-black" placeholder="What does this employee do well?"></textarea>
                    </div>
                    <div>
                        <label for="improvement" class="block text-lg font-medium text-gray-700 mb-2">Areas for Improvement:</label>
                        <textarea id="improvement" rows="4" class="w-full px-4 py-3 border border-gray-300 rounded-lg animated-placeholder focus:ring focus:ring-green-300 text-black" placeholder="Where can this employee improve?"></textarea>
                    </div>
                    <div>
                        <label for="additional-feedback" class="block text-lg font-medium text-gray-700 mb-2">Additional Comments:</label>
                        <textarea id="additional-feedback" rows="4" class="w-full px-4 py-3 border border-gray-300 rounded-lg animated-placeholder focus:ring focus:ring-green-300 text-black" placeholder="Any other feedback?"></textarea>
                    </div>
                </div>
            </div>

            <!-- Submit Button -->
            <button id="submitFeedback" class="w-full bg-gradient-to-r from-green-400 to-blue-500 text-white py-3 rounded-lg pulse-button font-bold mt-4">Submit Feedback</button>
            <div id="submitMessage" class="text-center text-red-600 font-bold mt-4"></div>
        </div>
    </main>

    <script>
        // Update employee name dynamically
        document.getElementById('employee').addEventListener('change', function() {
            const selectedOption = this.options[this.selectedIndex];
            const employeeName = selectedOption.text || "Selected Employee";
            document.getElementById('employeeName').innerText = employeeName;
        });

        // Submit feedback
        document.getElementById('submitFeedback').addEventListener('click', function() {
            const selectedEmployee = document.getElementById('employee').value;
            const strengths = document.getElementById('strengths').value.trim();
            const improvement = document.getElementById('improvement').value.trim();
            const additionalFeedback = document.getElementById('additional-feedback').value.trim();

            if (selectedEmployee && (strengths || improvement || additionalFeedback)) {
                document.getElementById('submitMessage').innerText = "Feedback submitted successfully!";
                // Clear fields after submission
                document.getElementById('strengths').value = '';
                document.getElementById('improvement').value = '';
                document.getElementById('additional-feedback').value = '';
            } else {
                document.getElementById('submitMessage').innerText = "Please fill out the required fields.";
            }
        });
    </script>
</body>
</html>

<?php include 'includes/script.php' ?>
<?php include 'includes/footer.php' ?>
