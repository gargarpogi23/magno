
<?php include 'includes/header.php' ?>
<?php include 'includes/navbar.php' ?>
<?php include 'includes/sidebar.php' ?>
<div id="layoutSidenav_content">

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Performance Tracker</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100 font-sans">

    <!-- Header Section -->
    <header class="bg-green-500 text-white flex justify-between items-center p-5">
        <h1 class="text-2xl">Performance Insights</h1>
        <div class="flex space-x-2">
            <input type="date" id="date-range" class="p-2 border rounded text-black" />
            <select id="team-selector" class="p-2 border rounded text-black">
                <option value="all-teams">All Teams</option>
                <option value="team-a">Team A</option>
                <option value="team-b">Team B</option>
            </select>
        </div>
    </header>

    <!-- KPI Section -->
    <section class="flex justify-around p-5 space-x-5">
        <div class="bg-white rounded-lg p-5 w-1/4 shadow hover:scale-105 transition-transform text-black">
            <h2 class="text-lg mb-2">Tasks Completed</h2>
            <p class="text-4xl text-green-600">85</p>
            <span class="text-gray-500">+5% from last month</span>
        </div>
        <div class="bg-white rounded-lg p-5 w-1/4 shadow hover:scale-105 transition-transform text-black">
            <h2 class="text-lg mb-2">Goals Achieved</h2>
            <p class="text-4xl text-green-600">12/15</p>
        </div>
        <div class="bg-white rounded-lg p-5 w-1/4 shadow hover:scale-105 transition-transform text-black">
            <h2 class="text-lg mb-2">Points Earned</h2>
            <p class="text-4xl text-green-600">420</p>
        </div>
        <div class="bg-white rounded-lg p-5 w-1/4 shadow hover:scale-105 transition-transform text-black">
            <h2 class="text-lg mb-2">Time Utilization</h2>
            <p class="text-4xl text-green-600">75%</p>
        </div>
    </section>

    <!-- Chart Section -->
    <section class="p-5 bg-white rounded-lg shadow mb-5 text-black">
        <h2 class="text-xl">Performance Trend</h2>
        <canvas id="performanceChart"></canvas>
    </section>

   

    <!-- Employee Performance Breakdown Section -->
    <section class="p-5 bg-white rounded-lg shadow mb-5 text-black">
        <h2 class="text-xl mb-3">Employee Performance Breakdown</h2>

        <!-- Filter and Sort Controls -->
        <div class="flex justify-between mb-5">
            <div class="flex items-center space-x-2">
                <label for="sort-selector" class="text-sm">Sort by:</label>
                <select id="sort-selector" class="p-2 border rounded">
                    <option value="name">Name</option>
                    <option value="points">Points Earned</option>
                    <option value="tasks">Tasks Completed</option>
                </select>
            </div>
            <div class="flex items-center space-x-2">
                <label for="search-employee" class="text-sm">Search Employee:</label>
                <input type="text" id="search-employee" placeholder="Enter employee name" class="p-2 border rounded" />
            </div>
        </div>

        <table id="employee-table" class="w-full border-collapse">
            <thead>
                <tr class="bg-green-600 text-white">
                    <th class="p-2 border">Employee Name</th>
                    <th class="p-2 border">Position</th>
                    <th class="p-2 border">Tasks Completed</th>
                    <th class="p-2 border">Points Earned</th>
                    <th class="p-2 border">Last Activity</th>
                </tr>
            </thead>
            <>
                <tr>
                    <td class="p-2 border">Jaycob Magno</td>
                    <td class="p-2 border">Senior Developer</td>
                    <td class="p-2 border">85</td>
                    <td class="p-2 border">420</td>
                    <td class="p-2 border">2024-10-16</td>
                </tr>
                <tr>
                    <td class="p-2 border">Edrianne Luangco</td>
                    <td class="p-2 border">UI/UX Designer</td>
                    <td class="p-2 border">75</td>
                    <td class="p-2 border">380</td>
                    <td class="p-2 border">2024-10-14</td>
                </tr>
                <tr>
                    <td class="p-2 border">Vegeta</td>
                    <td class="p-2 border">Project Manager</td>
                    <td class="p-2 border">65</td>
                    <td class="p-2 border">300</td>
                    <td class="p-2 border">2024-10-12</td>
                
                </tr>
            </tbody>
        </table>
    </section>

    <!-- Call to Action Section -->
    <section class="text-center mb-5">
        <button class="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700 transition">Set New Goal</button>
        <button class="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700 transition">Add Task</button>
    </section>

    <!-- JavaScript for Chart and Filtering/Sorting -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        var ctx = document.getElementById('performanceChart').getContext('2d');
        var performanceChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: ['January', 'February', 'March', 'April', 'May', 'June'],
                datasets: [{
                    label: 'Tasks Completed',
                    data: [65, 59, 80, 81, 56, 55],
                    backgroundColor: 'rgba(40, 167, 69, 0.2)',
                    borderColor: '#28a745',
                    borderWidth: 2,
                    fill: true
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });

        // Filtering and Sorting Functionality
        document.getElementById('search-employee').addEventListener('input', function() {
            const filterValue = this.value.toLowerCase();
            const rows = document.querySelectorAll('#employee-table tbody tr');
            rows.forEach(row => {
                const cell = row.querySelector('td:first-child'); // Employee Name
                if (cell.textContent.toLowerCase().includes(filterValue)) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        });

        document.getElementById('sort-selector').addEventListener('change', function() {
            const sortValue = this.value;
            const rows = Array.from(document.querySelectorAll('#employee-table tbody tr'));
            rows.sort((a, b) => {
                const aValue = sortValue === 'name' ? a.children[0].textContent : (sortValue === 'points' ? parseInt(a.children[3].textContent) : parseInt(a.children[2].textContent));
                const bValue = sortValue === 'name' ? b.children[0].textContent : (sortValue === 'points' ? parseInt(b.children[3].textContent) : parseInt(b.children[2].textContent));
                return aValue > bValue ? 1 : -1;
            });
            rows.forEach(row => document.querySelector('#employee-table tbody').appendChild(row));
        });
    </script>

</body>
</html>


<?php include 'includes/script.php' ?>
<?php include 'includes/footer.php' ?>
