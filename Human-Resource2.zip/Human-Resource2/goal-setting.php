<?php include 'includes/header.php'; ?>
<?php include 'includes/navbar.php'; ?>
<?php include 'includes/sidebar.php'; ?>
<div id="layoutSidenav_content">

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee Goal Setting</title>
    <!-- Include Tailwind CSS via CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 font-sans h-screen">

    <div class="flex items-center justify-center h-full">
        <div class="w-full max-w-20x2 bg-white p-8 rounded-lg shadow-md">
            <!-- Header Section -->
            <div class="bg-green-500 p-4 rounded-t-lg">
                <h2 class="text-white text-2xl font-bold text-center mb-6">Set Goal for Employee</h2>
            </div>

            <!-- Form Section -->
            <form action="#" method="post" class="space-y-6">
                <!-- Employee Selection -->
                <div>
                    <label for="employee" class=" block text-gray-700 font-semibold mb-2">Select Employee:</label>
                    <select id="employee" name="employee" class="w-full border border-gray-300 p-2 rounded-md bg-gray-100 text-gray-600" required>
                        <option value="">--Select Employee--</option>
                        <option value="emp1">Jaycob Magno</option>
                        <option value="emp2">Edrianne Luangco</option>
                        <option value="emp3">Vegeta Sama</option>
                    </select>
                </div>

                <!-- Goal Description -->
                <div>
                    <label for="goalDescription" class="block text-gray-700 font-semibold mb-2">Goal Description:</label>
                    <textarea id="goalDescription" name="goalDescription" rows="4" class="w-full border border-gray-300 p-2 rounded-md bg-gray-100 text-gray-600 placeholder-gray-400" placeholder="Describe the goal..." required></textarea>
                </div>

                <!-- Goal Due Date & Status -->
                <div class="flex flex-wrap -mx-2">
                    <!-- Goal Due Date -->
                    <div class="w-full md:w-1/2 px-2">
                        <label for="dueDate" class="block text-gray-700 font-semibold mb-2">Due Date:</label>
                        <input type="date" id="dueDate" name="dueDate" class="w-full border border-gray-300 p-2 rounded-md bg-gray-100 text-gray-600" required>
                    </div>

                    <!-- Goal Status -->
                    <div class="w-full md:w-1/2 px-2 mt-4 md:mt-0">
                        <label for="status" class="block text-gray-700 font-semibold mb-2">Status:</label>
                        <select id="status" name="status" class="w-full border border-gray-300 p-2 rounded-md bg-gray-100 text-gray-600" required>
                            <option value="">--Select Status--</option>
                            <option value="not-started">Not Started</option>
                            <option value="in-progress">In Progress</option>
                            <option value="completed">Completed</option>
                        </select>
                    </div>
                </div>

                <!-- Performance Indicator -->
                <div>
                    <label for="performanceIndicator" class="block text-gray-700 font-semibold mb-2">Performance Indicator:</label>
                    <select id="performanceIndicator" name="performanceIndicator" class="w-full border border-gray-300 p-2 rounded-md bg-gray-100 text-gray-600" required>
                        <option value="">--Select Performance Indicator--</option>
                        <option value="increase-sales">Achieve a 10% increase in quarterly sales revenue.</option>
                        <option value="quality-work">Quality of work</option>
                        <option value="communication-skills">Communication skills</option>
                    </select>
                </div>

                <!-- Support Required -->
                <div>
                    <label for="support" class="block text-gray-700 font-semibold mb-2">Support Needed:</label>
                    <textarea id="support" name="support" rows="3" class="w-full border border-gray-300 p-2 rounded-md bg-gray-100 text-gray-600" placeholder="Specify any support needed..." required></textarea>
                </div>

                <!-- Additional Notes -->
                <div>
                    <label for="notes" class="block text-gray-700 font-semibold mb-2">Additional Notes:</label>
                    <textarea id="notes" name="notes" rows="4" class="w-full border border-gray-300 p-2 rounded-md bg-gray-100 text-gray-600" placeholder="Any additional comments..."></textarea>
                </div>

                <!-- Submit Button -->
                <button type="submit" class="w-full bg-green-600 text-white py-2 rounded-md bg-gray-100 hover:bg-green-700">Set Goal</button>
            </form>
        </div>
    </div>

</body>
</html>

<?php include 'includes/script.php'; ?>
<?php include 'includes/footer.php'; ?>
